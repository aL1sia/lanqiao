alert("温馨提示:部分内容可能过于耀眼,请佩戴护目镜观看");

console.log("随便写的");

function searchBut(){
    alert("会但不多是这样的");

}

function openLink(){
    window.open('https://www.baidu.com','_blank');
}